==============================================
  LICENSE PLATE MANAGER
  A simple Python + Tkinter desktop app
==============================================

ABOUT
-----
This is a small desktop application built with Python and Tkinter.
It keeps a list of car license plates together with the service
each car needs. You can add a new plate, edit an existing one, or
remove it from the list.

It was my first project written with Tkinter.


FEATURES
--------
  * Add a new license plate with its service type
  * Edit an existing plate or change its service
  * Remove any plate from the list
  * Choose the service from a drop-down menu:
        Body, Inner, Engine, Full
  * The list shows every car as:  PLATE (Service)
  * A counter at the bottom shows how many cars are in the list
  * Input check: shows an error message if the plate is empty
    or the service is not valid


REQUIREMENTS
------------
  * PyCharm (the free Community edition is enough)
  * Python 3.13 as the project interpreter
  * Tkinter (it is included with the normal Python installation,
    nothing else needs to be installed)

You do NOT need VS Code or any other editor.


HOW TO RUN (with PyCharm)
-------------------------
  1. Download the project as a ZIP file and extract it.

  2. Open PyCharm and go to:
         File -> Open
     then select the extracted project folder.

  3. Set the interpreter to Python 3.13:
         File -> Settings -> Project -> Python Interpreter
         -> Add Interpreter -> choose Python 3.13

  4. Open the file  main.py  and click the green Run button
     (or press Shift + F10).


HOW TO USE
----------
  Add a plate:
     1. Type the plate in the text box (example: 10 ABC 123).
     2. Choose a service from the drop-down menu.
     3. Click "Add".

  Edit a plate:
     1. Click a car in the list. Its plate and service are
        loaded into the text box and the drop-down menu.
     2. Change the plate and/or the service.
     3. Click "Edit".

  Remove a plate:
     1. Click a car in the list.
     2. Click "Rem".


PROJECT FILES
-------------
  main.py     The whole application (run this file)
  README.txt  This file


NOTES
-----
  * The list is stored in memory only. When you close the
    program, the changes you made are not saved.
  * The program starts with some sample cars so you can
    try it right away.


AUTHOR
------
  Hannah Zebardast

