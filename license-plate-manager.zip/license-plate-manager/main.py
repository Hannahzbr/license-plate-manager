import tkinter as tk
import tkinter.ttk as ttk
from tkinter import messagebox as msg


class ButtonStandard(ttk.Button):
    def __init__(self, container, r, c, text, func, **kwargs):
        super().__init__(container, **kwargs)
        self.config(text=text)
        self.config(command=func)
        self.grid(row=r, column=c, sticky="NEWS", padx=2, pady=2)


class LabelStandard(ttk.Label):
    def __init__(self, container, r, c, text, var, **kwargs):
        super().__init__(container, **kwargs)
        self.config(text=text)
        self.config(textvariable=var)
        self.config(font="Arial 12")
        self.grid(row=r, column=c, sticky="NEWS", padx=2, pady=2)


class ComboStandard(ttk.Combobox):
    def __init__(self, container, r, c, var, **kwargs):
        super().__init__(container, **kwargs)
        self.config(textvariable=var)
        self.config(font="Arial 12")
        self.grid(row=r, column=c, sticky="NEWS", padx=2, pady=2)


class Spacer(ttk.Frame):
    def __init__(self, container, r, c, w, h, **kwargs):
        super().__init__(container, **kwargs)
        self.config(width=w, height=h)
        self.grid(row=r, column=c, sticky="NEWS")


class TextBoxStandard(ttk.Entry):
    def __init__(self, container, r, c, var, **kwargs):
        super().__init__(container, **kwargs)
        self.config(textvariable=var)
        self.config(font="Arial 12")
        self.grid(row=r, column=c, sticky="NEWS", padx=2, pady=2)


class ListBoxStandard(tk.Listbox):
    def __init__(self, container, r, c, var, func, **kwargs):
        super().__init__(container, **kwargs)
        self.config(listvariable=var)
        self.config(font="Arial 12")
        self.bind('<<ListboxSelect>>', func)
        self.grid(row=r, column=c, sticky="NEWS")
        self.config(exportselection=False)


class Application:
    def __init__(self):
        self.frm_main = tk.Tk()
        # self.frm_main.minsize(400,250)
        self.frm_main.geometry("500x250+750+100")
        self.frm_main.maxsize(500, 250)

        self.garage = {'88 ZLA 330': 'Inner', '68 QYL 224': 'Body', '10 KRD 717': 'Engine', '68 UVF 877': 'Inner',
                       '31 HLB 982': 'Engine', '30 TUC 228': 'Engine', '38 BNK 329': 'Engine', '81 LVS 548': 'Engine',
                       '86 MLF 371': 'Engine', '97 QKP 952': 'Engine', '81 CZT 422': 'Full', '69 AAF 547': 'Full',
                       '10 XQV 483': 'Full', '35 MLB 969': 'Full', '39 PQC 561': 'Body', '38 LUJ 403': 'Body',
                       '96 TIF 184': 'Full', '80 JDD 856': 'Inner', '52 JEE 613': 'Body', '46 FYW 446': 'Body',
                       '11 QRE 610': 'Full', '47 NKT 923': 'Full', '30 VHV 754': 'Inner', '53 IJN 995': 'Engine',
                       '10 GAR 543': 'Full', '18 FXJ 390': 'Full', '77 SVQ 429': 'Engine', '90 MKQ 151': 'Engine',
                       '41 IUX 218': 'Inner', '57 SNL 461': 'Engine', '90 LFT 860': 'Full', '50 UCE 208': 'Engine',
                       '44 XUC 880': 'Full', '31 TFC 858': 'Inner'}
        self.services = ['Body', 'Inner', 'Engine', 'Full']
        self.id_var = tk.StringVar()
        self.service_var = tk.StringVar()
        self.result_var = tk.StringVar()
        self.list_var = tk.Variable()

        Spacer(self.frm_main, 0, 0, 0, 0)

        Spacer(self.frm_main, 0, 1, 150, 0)
        Spacer(self.frm_main, 0, 2, 285, 0)

        for i in range(1, 7):
            Spacer(self.frm_main, i, 0, 0, 40)

        TextBoxStandard(self.frm_main, 1, 1, self.id_var)
        # TextBoxStandard(self.frm_main, 2, 1, self.service_var)
        ComboStandard(self.frm_main, 2, 1, self.service_var, values=self.services)
        ButtonStandard(self.frm_main, 3, 1, "Add", self.f_btn_add)
        ButtonStandard(self.frm_main, 4, 1, "Edit", self.f_btn_edit)
        ButtonStandard(self.frm_main, 5, 1, "Rem", self.f_btn_rem)
        ButtonStandard(self.frm_main, 6, 1, "Exit", self.f_btn_exit)

        self.lst = ListBoxStandard(self.frm_main, 1, 2, self.list_var, self.f_list_select)
        self.lst.grid(rowspan=5)
        LabelStandard(self.frm_main, 6, 2, "0 Cars", self.result_var)
        self.service_var.set('Body')
        self.f_listrefresh()

    def f_btn_add(self):
        id = self.id_var.get()
        ser = self.service_var.get()
        if len(id) > 0 and ser in self.services:
            self.garage[id] = ser
            self.f_listrefresh()
            self.id_var.set("")
        else:
            msg.showerror('Error', "Please Enter the ID & Service Correctly")

    def f_btn_edit(self):
        new_id = self.id_var.get()
        ser = self.service_var.get()
        if len(new_id) > 0 and ser in self.services:
            index = self.lst.curselection()[0]
            car_id = list(self.garage.keys())[index]
            self.garage.pop(car_id)
            self.garage[new_id] = ser
            self.f_listrefresh()
            self.id_var.set("")
        else:
            msg.showerror('Error', "Please Enter the ID & Service Correctly")

    def f_btn_rem(self):
        index = self.lst.curselection()[0]
        car_id = list(self.garage.keys())[index]
        self.garage.pop(car_id)
        self.f_listrefresh()
        self.id_var.set("")

    def f_list_select(self, event):
        index = self.lst.curselection()[0]
        car_id = list(self.garage.keys())[index]
        car_ser = self.garage[car_id]
        self.id_var.set(car_id)
        self.service_var.set(car_ser)

    def f_listrefresh(self):
        data = []
        for car in self.garage:
            data.append(f"{car} ({self.garage[car]})")
        self.list_var.set(data)
        self.result_var.set(f"{len(self.garage)} Cars.")

    def f_btn_exit(self):
        self.frm_main.destroy()

    def run(self):
        self.frm_main.mainloop()


a1 = Application()
a1.run()
